<?php

require_once "../Clases/AccesoDatos.php";
require_once "../Clases/Usuario.php";

use \Psr\Http\Message\ServerRequestInterface as Request; //alias
use \Psr\Http\Message\ResponseInterface as Response; //alias

require 'vendor/autoload.php'; //composer, referencia a slim framework

$app = new \Slim\App; //clase de slim framework

$app->get('/subir', function (Request $request, Response $response)
{

    $resultado = new stdclass();
    $resultado->mensaje = "ok POR GET";
    //$resultado->file =  $request->getParams()["file"];
   // var_dump("asdSADAsd");

    $response = $response->withJson($resultado);
    return $response->withHeader('Content-type', 'application/json');
});

$app->post('/subir', function (Request $request, Response $response)
{
   $resultado = new stdclass();
    // $resultado->mensaje = "ok";
    // $resultado->file =  $request->getParams()["file"];

    // $response = $response->withJson($request);
    // return $response->withHeader('Content-type', 'application/json');

   // var_dump($request->getUploadedFiles()["file"]);
	ECHO "ok POR post 999";
	 return $response
            ->withHeader('Access-Control-Allow-Origin', 'http://localhost:4201')
           ->withHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization')
            ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
	 // return $response->withHeader('Content-type', 'application/json');
});

$app->run();